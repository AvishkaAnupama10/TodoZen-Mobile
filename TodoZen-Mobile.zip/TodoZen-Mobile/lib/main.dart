import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:todozen/models/todo.dart';
import 'package:todozen/screens/welcome_screen.dart';
import 'package:todozen/screens/login_screen.dart';
import 'package:todozen/screens/signup_screen.dart';
import 'package:todozen/screens/home_screen.dart';
import 'package:todozen/screens/add_todo_screen.dart';
import 'package:todozen/screens/forgot_password_screen.dart';
import 'package:todozen/screens/todo_detail_screen.dart';
import 'package:todozen/screens/notifications_screen.dart';
import 'package:todozen/screens/settings_screen.dart';
import 'package:todozen/screens/task_analysis_screen.dart';
import 'package:todozen/screens/calendar_screen.dart';
import 'package:todozen/screens/help_feedback_screen.dart';
import 'package:todozen/services/auth_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize auth service
  await AuthService().init();
  
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
    ),
  );
  
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  ThemeMode _themeMode = ThemeMode.light;

  void _changeThemeMode() {
    setState(() {
      _themeMode = _themeMode == ThemeMode.light ? ThemeMode.dark : ThemeMode.light;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TodoZen',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.deepPurple,
          brightness: Brightness.light,
        ),
        useMaterial3: true,
        fontFamily: 'Poppins',
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.deepPurple,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
        fontFamily: 'Poppins',
      ),
      themeMode: _themeMode,
      initialRoute: WelcomeScreen.routeName,
      routes: {
        WelcomeScreen.routeName: (context) => const WelcomeScreen(),
        '/login': (context) => const LoginScreen(),
        '/signup': (context) => const SignupScreen(),
        '/forgot-password': (context) => const ForgotPasswordScreen(),
        '/home': (context) => HomeScreen(onThemeChanged: _changeThemeMode),
        '/add-todo': (context) => const AddTodoScreen(),
        '/notifications': (context) => const NotificationsScreen(),
        '/settings': (context) => const SettingsScreen(),
        '/task-analysis': (context) => const TaskAnalysisScreen(),
        '/calendar': (context) => const CalendarScreen(),
        '/help-feedback': (context) => const HelpFeedbackScreen(),
      },
      onGenerateRoute: (settings) {
        if (settings.name == '/todo-detail') {
          return MaterialPageRoute(
            builder: (context) => TodoDetailScreen(todo: settings.arguments as Todo),
          );
        }
        return null;
      },
      navigatorObservers: [
        NavigatorObserver(),
      ],
      builder: (context, child) {
        ErrorWidget.builder = (FlutterErrorDetails details) {
          return Material(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.error_outline, size: 60, color: Colors.red),
                  const SizedBox(height: 16),
                  Text(
                    'An error occurred.',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  ElevatedButton(
                    onPressed: () => Navigator.of(context).pushNamedAndRemoveUntil('/home', (route) => false),
                    child: const Text('Return to Home'),
                  ),
                ],
              ),
            ),
          );
        };
        
        return child ?? Container();
      },
    );
  }
}

class StartupScreen extends StatefulWidget {
  const StartupScreen({Key? key}) : super(key: key);

  @override
  State<StartupScreen> createState() => _StartupScreenState();
}

class _StartupScreenState extends State<StartupScreen> {
  @override
  void initState() {
    super.initState();
    _checkAuthStatus();
  }

  Future<void> _checkAuthStatus() async {
    try {
      // Add a small delay to prevent jarring transition
      await Future.delayed(const Duration(milliseconds: 500));
      
      final isLoggedIn = await AuthService().isLoggedIn();
      
      if (mounted) {
        Navigator.pushNamedAndRemoveUntil(
          context,
          isLoggedIn ? '/home' : '/welcome',
          (route) => false,
        );
      }
    } catch (e) {
      // In case of error, default to welcome screen
      if (mounted) {
        Navigator.pushReplacementNamed(context, '/welcome');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.deepPurple.shade200,
              Colors.deepPurple.shade600,
            ],
          ),
        ),
        child: const Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.spa,
                size: 80,
                color: Colors.white,
              ),
              SizedBox(height: 24),
              Text(
                'TodoZen',
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  letterSpacing: 2,
                ),
              ),
              SizedBox(height: 48),
              CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
