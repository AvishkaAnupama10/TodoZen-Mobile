import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';
import '../screens/welcome_screen.dart';

class User {
  final String? id;
  final String? name;
  final String? email;
  final String? photoUrl;
  
  User({this.id, this.name, this.email, this.photoUrl});
}

class AuthService {
  static final AuthService _instance = AuthService._internal();
  
  factory AuthService() => _instance;
  
  AuthService._internal();
  
  SharedPreferences? _prefs;
  User? _currentUser;
  
  User? get currentUser => _currentUser;
  
  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    
    // Check if user is logged in
    final isLoggedIn = _prefs?.getBool('isLoggedIn') ?? false;
    if (isLoggedIn) {
      _loadUserFromStorage();
    }
  }
  
  void _loadUserFromStorage() {
    final id = _prefs?.getString('userId');
    final name = _prefs?.getString('userName');
    final email = _prefs?.getString('userEmail');
    final photoUrl = _prefs?.getString('userPhotoUrl');
    
    if (id != null && email != null) {
      _currentUser = User(
        id: id,
        name: name,
        email: email,
        photoUrl: photoUrl,
      );
    }
  }
  
  Future<bool> isLoggedIn() async {
    return _prefs?.getBool('isLoggedIn') ?? false;
  }
  
  Future<User> login(String email, String password) async {
    try {
      // Simulate API call delay
      await Future.delayed(const Duration(seconds: 1));
      
      // For demo, we'll just check if it's a demo account
      if (email == 'demo@example.com' && password == 'password') {
        const userId = 'demo-123';
        const userName = 'Demo User';
        const userEmail = 'demo@example.com';
        const userPhotoUrl = 'https://ui-avatars.com/api/?name=Demo+User&background=random';
        
        // Save user info
        await _prefs?.setString('userId', userId);
        await _prefs?.setString('userName', userName);
        await _prefs?.setString('userEmail', userEmail);
        await _prefs?.setString('userPhotoUrl', userPhotoUrl);
        await _prefs?.setBool('isLoggedIn', true);
        
        _currentUser = User(
          id: userId,
          name: userName,
          email: userEmail,
          photoUrl: userPhotoUrl,
        );
        
        return _currentUser!;
      } else {
        throw Exception('Invalid credentials');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Login error: $e');
      }
      throw Exception('Login failed: $e');
    }
  }
  
  Future<User> signup({
    required String name,
    required String email,
    required String password,
  }) async {
    try {
      // Simulate API call delay
      await Future.delayed(const Duration(seconds: 1));
      
      // For demo, create a new user with provided info
      final userId = 'user-${DateTime.now().millisecondsSinceEpoch}';
      final userName = name;
      final userEmail = email;
      final userPhotoUrl = 'https://ui-avatars.com/api/?name=${name.replaceAll(' ', '+')}&background=random';
      
      // Save user info
      await _prefs?.setString('userId', userId);
      await _prefs?.setString('userName', userName);
      await _prefs?.setString('userEmail', userEmail);
      await _prefs?.setString('userPhotoUrl', userPhotoUrl);
      await _prefs?.setBool('isLoggedIn', true);
      
      _currentUser = User(
        id: userId,
        name: userName,
        email: userEmail,
        photoUrl: userPhotoUrl,
      );
      
      return _currentUser!;
    } catch (e) {
      if (kDebugMode) {
        print('Signup error: $e');
      }
      throw Exception('Signup failed: $e');
    }
  }
  
  Future<void> logout() async {
    await _prefs?.setBool('isLoggedIn', false);
    _currentUser = null;
  }

  static Future<void> logoutAndNavigate(BuildContext context) async {
    // Use the factory constructor to get the singleton instance
    final authService = AuthService();
    
    // Call logout on the instance
    await authService.logout();
    
    // Then navigate to welcome screen
    if (context.mounted) {
      Navigator.of(context).pushNamedAndRemoveUntil(
        WelcomeScreen.routeName, 
        (route) => false
      );
    }
  }
  
  Future<void> resetPassword(String email) async {
    // Simulate API call
    await Future.delayed(const Duration(seconds: 1));
    
    // In a real app, this would send a password reset email
    return;
  }
}
