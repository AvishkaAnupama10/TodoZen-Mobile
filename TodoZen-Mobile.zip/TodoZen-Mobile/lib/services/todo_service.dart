import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/todo.dart';

class TodoService {
  static const String _todosKey = 'todos';
  List<Todo> _todos = [];
  
  // Singleton pattern
  static final TodoService _instance = TodoService._internal();
  
  factory TodoService() {
    return _instance;
  }
  
  TodoService._internal();
  
  List<Todo> get todos => _todos;
  
  Future<void> initialize() async {
    await loadTodos();
  }
  
  Future<void> loadTodos() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final todosString = prefs.getString(_todosKey);
      
      if (todosString != null) {
        final List<dynamic> jsonList = jsonDecode(todosString);
        _todos = jsonList.map((json) => Todo.fromJson(json)).toList();
      } else {
        // Add some sample todos if no saved todos exist
        _generateSampleTodos();
      }
    } catch (e) {
      print('Error loading todos: $e');
      _generateSampleTodos();
    }
  }
  
  void _generateSampleTodos() {
    _todos = [
      Todo(
        id: 1,
        title: 'Complete project proposal',
        description: 'Finalize the proposal document and send it to the manager by EOD',
        dueDate: DateTime.now().add(const Duration(days: 2)),
        priority: 'High',
        createdAt: DateTime.now(),
        tags: ['Work', 'Project'],
        subtasks: [
          Subtask(id: 1, title: 'Write introduction', createdAt: DateTime.now()),
          Subtask(id: 2, title: 'Create budget plan', createdAt: DateTime.now()),
          Subtask(id: 3, title: 'Make presentation', createdAt: DateTime.now()),
        ],
      ),
      Todo(
        id: 2,
        title: 'Buy groceries for weekend',
        description: 'Milk, eggs, bread, fruits, vegetables, and snacks for movie night',
        dueDate: DateTime.now().add(const Duration(days: 1)),
        priority: 'Medium',
        isCompleted: true,
        createdAt: DateTime.now().subtract(const Duration(days: 1)),
        tags: ['Shopping', 'Personal'],
      ),
      Todo(
        id: 3,
        title: 'Schedule dentist appointment',
        description: 'Call Dr. Smith for a routine check-up',
        dueDate: DateTime.now().add(const Duration(days: 5)),
        priority: 'Low',
        createdAt: DateTime.now().subtract(const Duration(days: 2)),
        tags: ['Health', 'Personal'],
      ),
      Todo(
        id: 4,
        title: 'Prepare presentation slides',
        description: 'Create slides for the quarterly business review meeting',
        dueDate: DateTime.now().add(const Duration(days: 3)),
        priority: 'High',
        createdAt: DateTime.now().subtract(const Duration(days: 3)),
        tags: ['Work', 'Presentation'],
        subtasks: [
          Subtask(id: 4, title: 'Gather data', createdAt: DateTime.now()),
          Subtask(id: 5, title: 'Design charts', createdAt: DateTime.now()),
        ],
      ),
      Todo(
        id: 5,
        title: 'Pay utility bills',
        description: 'Electricity, water, and internet bills due this month',
        dueDate: DateTime.now().add(const Duration(days: 1)),
        priority: 'Medium',
        createdAt: DateTime.now().subtract(const Duration(days: 4)),
        tags: ['Finance', 'Home'],
      ),
    ];
  }
  
  Future<void> saveTodos() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final todosJson = _todos.map((todo) => todo.toJson()).toList();
      await prefs.setString(_todosKey, jsonEncode(todosJson));
    } catch (e) {
      print('Error saving todos: $e');
    }
  }
  
  Future<Todo> addTodo(Todo todo) async {
    final newId = _getNextId();
    final newTodo = Todo(
      id: newId,
      title: todo.title,
      description: todo.description,
      dueDate: todo.dueDate,
      isCompleted: todo.isCompleted,
      priority: todo.priority,
      categoryId: todo.categoryId,
      hasReminder: todo.hasReminder,
      reminderTime: todo.reminderTime,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
      tags: todo.tags,
      subtasks: todo.subtasks,
    );
    
    _todos.add(newTodo);
    await saveTodos();
    return newTodo;
  }
  
  Future<Todo?> updateTodo(Todo updatedTodo) async {
    final index = _todos.indexWhere((todo) => todo.id == updatedTodo.id);
    
    if (index != -1) {
      // Update the todo with new values, but preserve creation date
      final Todo todoToUpdate = _todos[index];
      final updatedWithTimestamp = Todo(
        id: updatedTodo.id,
        title: updatedTodo.title,
        description: updatedTodo.description,
        dueDate: updatedTodo.dueDate,
        isCompleted: updatedTodo.isCompleted,
        priority: updatedTodo.priority,
        categoryId: updatedTodo.categoryId,
        hasReminder: updatedTodo.hasReminder,
        reminderTime: updatedTodo.reminderTime,
        createdAt: todoToUpdate.createdAt,
        updatedAt: DateTime.now(),
        tags: updatedTodo.tags,
        subtasks: updatedTodo.subtasks,
      );
      
      _todos[index] = updatedWithTimestamp;
      await saveTodos();
      return updatedWithTimestamp;
    }
    
    return null;
  }
  
  Future<bool> deleteTodo(int id) async {
    final initialLength = _todos.length;
    _todos.removeWhere((todo) => todo.id == id);
    
    if (_todos.length < initialLength) {
      await saveTodos();
      return true;
    }
    
    return false;
  }
  
  int _getNextId() {
    if (_todos.isEmpty) return 1;
    return _todos.map((todo) => todo.id ?? 0).reduce((max, id) => id > max ? id : max) + 1;
  }
  
  Future<void> toggleTodoCompletion(int id, bool isCompleted) async {
    final index = _todos.indexWhere((todo) => todo.id == id);
    
    if (index != -1) {
      _todos[index] = _todos[index].copyWith(
        isCompleted: isCompleted,
        updatedAt: DateTime.now(),
      );
      await saveTodos();
    }
  }
  
  Future<void> toggleSubtaskCompletion(int todoId, int subtaskId, bool isCompleted) async {
    final todoIndex = _todos.indexWhere((todo) => todo.id == todoId);
    
    if (todoIndex != -1 && _todos[todoIndex].subtasks != null) {
      final subtaskIndex = _todos[todoIndex].subtasks!.indexWhere((subtask) => subtask.id == subtaskId);
      
      if (subtaskIndex != -1) {
        final updatedSubtasks = List<Subtask>.from(_todos[todoIndex].subtasks!);
        updatedSubtasks[subtaskIndex] = updatedSubtasks[subtaskIndex].copyWith(isCompleted: isCompleted);
        
        _todos[todoIndex] = _todos[todoIndex].copyWith(
          subtasks: updatedSubtasks,
          updatedAt: DateTime.now(),
        );
        
        await saveTodos();
      }
    }
  }
  
  List<Todo> filterTodos({
    String filter = 'All',
    String searchQuery = '',
    String sortBy = 'Due Date',
    bool sortAscending = true,
  }) {
    List<Todo> filteredTodos;
    
    // Apply filter
    switch (filter) {
      case 'Completed':
        filteredTodos = _todos.where((todo) => todo.isCompleted).toList();
        break;
      case 'Pending':
        filteredTodos = _todos.where((todo) => !todo.isCompleted).toList();
        break;
      case 'High Priority':
        filteredTodos = _todos.where((todo) => todo.priority == 'High').toList();
        break;
      case 'Overdue':
        final now = DateTime.now();
        filteredTodos = _todos.where((todo) =>
            !todo.isCompleted && todo.dueDate.isBefore(now)).toList();
        break;
      case 'Today':
        final now = DateTime.now();
        filteredTodos = _todos.where((todo) {
          final todoDate = DateTime(todo.dueDate.year, todo.dueDate.month, todo.dueDate.day);
          final currentDate = DateTime(now.year, now.month, now.day);
          return todoDate.isAtSameMomentAs(currentDate);
        }).toList();
        break;
      case 'All':
      default:
        filteredTodos = List.from(_todos);
    }
    
    // Apply search
    if (searchQuery.isNotEmpty) {
      filteredTodos = filteredTodos.where((todo) {
        final title = todo.title.toLowerCase();
        final description = todo.description.toLowerCase();
        final query = searchQuery.toLowerCase();
        
        // Also search in tags
        final hasMatchingTag = todo.tags.any((tag) => tag.toLowerCase().contains(query));
        
        return title.contains(query) || description.contains(query) || hasMatchingTag;
      }).toList();
    }
    
    // Apply sorting
    _sortTodos(filteredTodos, sortBy, sortAscending);
    
    return filteredTodos;
  }
  
  void _sortTodos(List<Todo> todoList, String sortBy, bool ascending) {
    switch (sortBy) {
      case 'Due Date':
        todoList.sort((a, b) => a.dueDate.compareTo(b.dueDate));
        break;
      case 'Priority':
        todoList.sort((a, b) {
          final priorityOrder = {
            'High': 0,
            'Medium': 1,
            'Low': 2,
          };
          return priorityOrder[a.priority]!.compareTo(priorityOrder[b.priority]!);
        });
        break;
      case 'Title':
        todoList.sort((a, b) => a.title.compareTo(b.title));
        break;
      case 'Creation Date':
        todoList.sort((a, b) => (a.createdAt ?? DateTime.now())
            .compareTo(b.createdAt ?? DateTime.now()));
        break;
    }
    
    if (!ascending) {
      todoList.reverseRange(0, todoList.length);
    }
  }
  
  List<String> getAllTags() {
    final Set<String> allTags = {};
    for (final todo in _todos) {
      allTags.addAll(todo.tags);
    }
    return allTags.toList()..sort();
  }
  
  double getCompletionRate() {
    if (_todos.isEmpty) return 0.0;
    final completedTasks = _todos.where((todo) => todo.isCompleted).length;
    return completedTasks / _todos.length;
  }
}

extension on List<Todo> {
  void reverseRange(int i, int length) {}
}
