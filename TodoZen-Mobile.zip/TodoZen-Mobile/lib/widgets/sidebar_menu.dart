import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class SidebarMenu extends StatelessWidget {
  final Function? onThemeChanged;
  
  const SidebarMenu({Key? key, this.onThemeChanged}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final user = AuthService().currentUser;
    final theme = Theme.of(context);
    
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          UserAccountsDrawerHeader(
            accountName: Text(user?.name ?? 'Guest User'),
            accountEmail: Text(user?.email ?? 'guest@example.com'),
            currentAccountPicture: CircleAvatar(
              backgroundImage: user?.photoUrl != null 
                ? NetworkImage(user!.photoUrl!) as ImageProvider
                : const AssetImage('assets/images/default_avatar.png'),
              backgroundColor: Colors.white,
            ),
            decoration: BoxDecoration(
              color: theme.colorScheme.primary,
            ),
          ),
          ListTile(
            leading: const Icon(Icons.home),
            title: const Text('Home'),
            onTap: () {
              Navigator.pop(context);
              Navigator.pushReplacementNamed(context, '/home');
            },
          ),
          ListTile(
            leading: const Icon(Icons.calendar_today),
            title: const Text('Calendar'),
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/calendar');
            },
          ),
          ListTile(
            leading: const Icon(Icons.assessment),
            title: const Text('Task Analysis'),
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/task-analysis');
            },
          ),
          ListTile(
            leading: const Icon(Icons.notifications),
            title: const Text('Notifications'),
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/notifications');
            },
          ),
          ListTile(
            leading: const Icon(Icons.settings),
            title: const Text('Settings'),
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/settings');
            },
          ),
          ListTile(
            leading: const Icon(Icons.help_outline),
            title: const Text('Help & Feedback'),
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/help-feedback');
            },
          ),
          const Divider(),
          if (onThemeChanged != null)
            ListTile(
              leading: const Icon(Icons.brightness_6),
              title: const Text('Toggle Theme'),
              onTap: () {
                onThemeChanged!();
                Navigator.pop(context);
              },
            ),
          ListTile(
            leading: const Icon(Icons.logout),
            title: const Text('Logout'),
            onTap: () {
              // Close the drawer first
              Navigator.pop(context);
              // Use the updated method that handles both logout and navigation
              AuthService.logoutAndNavigate(context);
            },
          ),
        ],
      ),
    );
  }
}
