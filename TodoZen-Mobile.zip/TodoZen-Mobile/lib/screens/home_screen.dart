import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:todozen/screens/analytics_screen.dart';
import 'package:todozen/screens/calendar_screen.dart';
import 'package:todozen/screens/help_screen.dart';
import 'package:todozen/screens/profile_screen.dart';
import 'package:todozen/screens/settings_screen.dart';
import 'package:todozen/screens/notifications_screen.dart';
import 'package:todozen/screens/task_analysis_screen.dart';
import '../models/todo.dart';
import '../services/auth_service.dart';
import 'dart:ui';

class HomeScreen extends StatefulWidget {
  final VoidCallback? onThemeChanged;

  const HomeScreen({
    super.key,
    this.onThemeChanged,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  List<Todo> todos = [
    Todo(
      id: 1,
      title: 'Complete project proposal',
      description: 'Finalize the proposal document and send it to the manager by EOD',
      dueDate: DateTime.now().add(const Duration(days: 2)),
      priority: 'High',
    ),
    Todo(
      id: 2,
      title: 'Buy groceries for weekend',
      description: 'Milk, eggs, bread, fruits, vegetables, and snacks for movie night',
      dueDate: DateTime.now().add(const Duration(days: 1)),
      priority: 'Medium',
      isCompleted: true,
    ),
    Todo(
      id: 3,
      title: 'Schedule dentist appointment',
      description: 'Call Dr. Smith for a routine check-up',
      dueDate: DateTime.now().add(const Duration(days: 5)),
      priority: 'Low',
    ),
    Todo(
      id: 4,
      title: 'Prepare presentation slides',
      description: 'Create slides for the quarterly business review meeting',
      dueDate: DateTime.now().add(const Duration(days: 3)),
      priority: 'High',
    ),
    Todo(
      id: 5,
      title: 'Pay utility bills',
      description: 'Electricity, water, and internet bills due this month',
      dueDate: DateTime.now().add(const Duration(days: 1)),
      priority: 'Medium',
    ),
  ];

  String _filter = 'All';
  String _sortBy = 'Due Date';
  bool _sortAscending = true;

  List<String> get sortOptions => ['Due Date', 'Priority', 'Title', 'Creation Date'];

  final user = AuthService().currentUser;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  bool _showFab = true;
  late ScrollController _scrollController;

  bool _isSearching = false;
  String _searchQuery = '';
  late TextEditingController _searchController;

  late TabController _tabController;

  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeIn,
      ),
    );

    _scrollController = ScrollController();
    _scrollController.addListener(() {
      if (_scrollController.position.userScrollDirection == ScrollDirection.reverse) {
        if (_showFab) {
          setState(() {
            _showFab = false;
          });
        }
      }
      if (_scrollController.position.userScrollDirection == ScrollDirection.forward) {
        if (!_showFab) {
          setState(() {
            _showFab = true;
          });
        }
      }
    });

    _searchController = TextEditingController();

    _tabController = TabController(length: 3, vsync: this);

    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    _scrollController.dispose();
    _searchController.dispose();
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _logout() async {
    try {
      setState(() {
        _isLoading = true;
      });

      await AuthService().logout();

      if (mounted) {
        Navigator.pushNamedAndRemoveUntil(
          context,
          '/welcome',
          (route) => false,
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error logging out: ${e.toString()}')),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _showLogoutConfirmation() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirm Logout'),
        content: const Text('Are you sure you want to log out? Your tasks will still be saved for next time.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _logout();
            },
            style: TextButton.styleFrom(
              foregroundColor: Colors.red,
            ),
            child: const Text('Logout'),
          ),
        ],
      ),
    );
  }

  String _getDaysRemaining(DateTime dueDate) {
    final today = DateTime.now();
    final difference = dueDate.difference(today).inDays;

    if (difference < 0) {
      return 'Overdue';
    } else if (difference == 0) {
      return 'Today';
    } else if (difference == 1) {
      return 'Tomorrow';
    } else {
      return '$difference days left';
    }
  }

  Color _getDueDateColor(DateTime dueDate) {
    final today = DateTime.now();
    final difference = dueDate.difference(today).inDays;

    if (difference < 0) {
      return Colors.red;
    } else if (difference <= 1) {
      return Colors.orange;
    } else {
      return Colors.green;
    }
  }

  void _showFilterDialog() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom + 16,
              ),
              child: SingleChildScrollView(
                child: Container(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Filter & Sort',
                            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.close),
                            onPressed: () => Navigator.pop(context),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'Filter tasks',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        children: [
                          FilterChip(
                            label: const Text('All'),
                            selected: _filter == 'All',
                            onSelected: (selected) {
                              if (selected) {
                                setModalState(() {
                                  _filter = 'All';
                                });
                                setState(() {
                                  _filter = 'All';
                                });
                              }
                            },
                          ),
                          FilterChip(
                            label: const Text('Completed'),
                            selected: _filter == 'Completed',
                            onSelected: (selected) {
                              if (selected) {
                                setModalState(() {
                                  _filter = 'Completed';
                                });
                                setState(() {
                                  _filter = 'Completed';
                                });
                              }
                            },
                          ),
                          FilterChip(
                            label: const Text('Pending'),
                            selected: _filter == 'Pending',
                            onSelected: (selected) {
                              if (selected) {
                                setModalState(() {
                                  _filter = 'Pending';
                                });
                                setState(() {
                                  _filter = 'Pending';
                                });
                              }
                            },
                          ),
                          FilterChip(
                            label: const Text('High Priority'),
                            selected: _filter == 'High Priority',
                            onSelected: (selected) {
                              if (selected) {
                                setModalState(() {
                                  _filter = 'High Priority';
                                });
                                setState(() {
                                  _filter = 'High Priority';
                                });
                              }
                            },
                          ),
                          FilterChip(
                            label: const Text('Overdue'),
                            selected: _filter == 'Overdue',
                            onSelected: (selected) {
                              if (selected) {
                                setModalState(() {
                                  _filter = 'Overdue';
                                });
                                setState(() {
                                  _filter = 'Overdue';
                                });
                              }
                            },
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'Sort by',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        children: sortOptions.map((option) {
                          return FilterChip(
                            label: Text(option),
                            selected: _sortBy == option,
                            onSelected: (selected) {
                              if (selected) {
                                setModalState(() {
                                  _sortBy = option;
                                });
                                setState(() {
                                  _sortBy = option;
                                });
                              }
                            },
                          );
                        }).toList(),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Text(
                            'Order:',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(width: 8),
                          ChoiceChip(
                            label: const Text('Ascending'),
                            selected: _sortAscending,
                            onSelected: (selected) {
                              if (selected) {
                                setModalState(() {
                                  _sortAscending = true;
                                });
                                setState(() {
                                  _sortAscending = true;
                                });
                              }
                            },
                          ),
                          const SizedBox(width: 8),
                          ChoiceChip(
                            label: const Text('Descending'),
                            selected: !_sortAscending,
                            onSelected: (selected) {
                              if (selected) {
                                setModalState(() {
                                  _sortAscending = false;
                                });
                                setState(() {
                                  _sortAscending = false;
                                });
                              }
                            },
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                          _sortTodos();
                        },
                        child: const Text('Apply'),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _sortTodos() {
    setState(() {
      switch (_sortBy) {
        case 'Due Date':
          todos.sort((a, b) => a.dueDate.compareTo(b.dueDate));
          break;
        case 'Priority':
          todos.sort((a, b) {
            final priorityOrder = {
              'High': 0,
              'Medium': 1,
              'Low': 2,
            };
            return priorityOrder[a.priority]!.compareTo(priorityOrder[b.priority]!);
          });
          break;
        case 'Title':
          todos.sort((a, b) => a.title.compareTo(b.title));
          break;
        case 'Creation Date':
          todos.sort((a, b) => (a.id ?? 0).compareTo(b.id ?? 0));
          break;
      }

      if (!_sortAscending) {
        todos = todos.reversed.toList();
      }
    });
  }

  List<Todo> _getFilteredTodos() {
    List<Todo> filteredTodos;

    switch (_filter) {
      case 'Completed':
        filteredTodos = todos.where((todo) => todo.isCompleted).toList();
        break;
      case 'Pending':
        filteredTodos = todos.where((todo) => !todo.isCompleted).toList();
        break;
      case 'High Priority':
        filteredTodos = todos.where((todo) => todo.priority == 'High').toList();
        break;
      case 'Overdue':
        final now = DateTime.now();
        filteredTodos = todos.where((todo) =>
            !todo.isCompleted && todo.dueDate.isBefore(now)).toList();
        break;
      case 'All':
      default:
        filteredTodos = List.from(todos);
    }

    if (_searchQuery.isNotEmpty) {
      filteredTodos = filteredTodos.where((todo) {
        return todo.title.toLowerCase().contains(_searchQuery.toLowerCase()) ||
               todo.description.toLowerCase().contains(_searchQuery.toLowerCase());
      }).toList();
    }

    return filteredTodos;
  }

  void _startSearch() {
    setState(() {
      _isSearching = true;
    });
  }

  void _stopSearch() {
    setState(() {
      _isSearching = false;
      _searchQuery = '';
      _searchController.clear();
    });
  }

  void _updateSearchQuery(String newQuery) {
    setState(() {
      _searchQuery = newQuery;
    });
  }

  Future<void> _navigateToEditTask(Todo todo) async {
    final todoToEdit = Todo(
      id: todo.id,
      title: todo.title,
      description: todo.description,
      dueDate: todo.dueDate,
      isCompleted: todo.isCompleted,
      priority: todo.priority,
      categoryId: todo.categoryId,
      hasReminder: todo.hasReminder,
      reminderTime: todo.reminderTime,
      createdAt: todo.createdAt,
      updatedAt: todo.updatedAt,
      tags: todo.tags,
    );
    
    final result = await Navigator.pushNamed(
      context,
      '/add-todo',
      arguments: todoToEdit,
    );
    
    if (result != null) {
      if (result == 'delete') {
        setState(() {
          todos = todos.where((t) => t.id != todo.id).toList();
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Task deleted')),
        );
      } else if (result is Todo) {
        setState(() {
          todos = todos.map((t) => t.id == result.id ? result : t).toList();
        });
        _sortTodos();
        
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Task updated')),
        );
      }
    }
  }

  Widget _buildTaskCard(Todo todo) {
    final dueText = _getDaysRemaining(todo.dueDate);
    final dueColor = _getDueDateColor(todo.dueDate);

    return Hero(
      tag: 'todo-${todo.id}',
      child: Card(
        margin: const EdgeInsets.only(bottom: 16),
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(
            color: todo.priority == 'High'
                ? Colors.red.withOpacity(0.3)
                : todo.priority == 'Medium'
                    ? Colors.orange.withOpacity(0.3)
                    : Colors.green.withOpacity(0.3),
            width: 1,
          ),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () async {
            final todoCopy = Todo(
              id: todo.id,
              title: todo.title,
              description: todo.description,
              dueDate: todo.dueDate,
              isCompleted: todo.isCompleted,
              priority: todo.priority,
              categoryId: todo.categoryId,
              hasReminder: todo.hasReminder,
              reminderTime: todo.reminderTime,
              createdAt: todo.createdAt,
              updatedAt: todo.updatedAt,
            );
            
            final result = await Navigator.pushNamed(
              context,
              '/todo-detail',
              arguments: todoCopy,
            );
            
            if (result != null) {
              if (result == 'delete') {
                setState(() {
                  todos = todos.where((t) => t.id != todo.id).toList();
                });
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Task deleted')),
                );
              } else if (result is Todo) {
                setState(() {
                  todos = todos.map((t) => t.id == result.id ? result : t).toList();
                });
                _sortTodos();
              }
            }
          },
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Transform.scale(
                      scale: 1.2,
                      child: Checkbox(
                        value: todo.isCompleted,
                        activeColor: Theme.of(context).colorScheme.primary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(4),
                        ),
                        onChanged: (bool? value) {
                          _toggleTaskCompletion(todo, value);
                        },
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            todo.title,
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              decoration: todo.isCompleted
                                  ? TextDecoration.lineThrough
                                  : TextDecoration.none,
                              color: todo.isCompleted
                                  ? Colors.grey
                                  : Colors.black87,
                            ),
                          ),
                          if (todo.description.isNotEmpty) ...[
                            const SizedBox(height: 4),
                            Text(
                              todo.description.length > 60
                                  ? '${todo.description.substring(0, 60)}...'
                                  : todo.description,
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey.shade600,
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: todo.priority == 'High'
                              ? [Colors.red.shade300, Colors.red.shade400]
                              : todo.priority == 'Medium'
                                  ? [Colors.orange.shade300, Colors.orange.shade400]
                                  : [Colors.green.shade300, Colors.green.shade400],
                        ),
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: todo.priority == 'High'
                                ? Colors.red.withOpacity(0.3)
                                : todo.priority == 'Medium'
                                    ? Colors.orange.withOpacity(0.3)
                                    : Colors.green.withOpacity(0.3),
                            blurRadius: 4,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Text(
                        todo.priority,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.calendar_today,
                          size: 16,
                          color: dueColor,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          dueText,
                          style: TextStyle(
                            fontSize: 14,
                            color: dueColor,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                    IconButton(
                      icon: const Icon(Icons.more_vert),
                      onPressed: () => _showTaskOptionsModal(todo),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _toggleTaskCompletion(Todo todo, bool? value) {
    if (value == null) return;
    
    setState(() {
      final updatedTodo = Todo(
        id: todo.id,
        title: todo.title,
        description: todo.description,
        dueDate: todo.dueDate,
        isCompleted: value,
        priority: todo.priority,
        categoryId: todo.categoryId,
        hasReminder: todo.hasReminder,
        reminderTime: todo.reminderTime,
        createdAt: todo.createdAt,
        updatedAt: DateTime.now(),
      );
      
      todos = todos.map((t) => t.id == todo.id ? updatedTodo : t).toList();
    });
  }

  void _showTaskOptionsModal(Todo todo) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 16),
              ListTile(
                leading: const Icon(Icons.edit, color: Colors.blue),
                title: const Text('Edit Task'),
                subtitle: const Text('Change task details'),
                onTap: () {
                  Navigator.pop(context);
                  _navigateToEditTask(todo);
                },
              ),
              ListTile(
                leading: Icon(
                  todo.isCompleted ? Icons.refresh : Icons.check_circle,
                  color: todo.isCompleted ? Colors.orange : Colors.green,
                ),
                title: Text(
                  todo.isCompleted ? 'Mark as Incomplete' : 'Mark as Complete',
                ),
                subtitle: Text(
                  todo.isCompleted 
                      ? 'Change status to pending' 
                      : 'Change status to completed'
                ),
                onTap: () {
                  Navigator.pop(context);
                  setState(() {
                    todo.isCompleted = !todo.isCompleted;
                  });
                },
              ),
              ListTile(
                leading: const Icon(Icons.delete, color: Colors.red),
                title: const Text('Delete Task'),
                subtitle: const Text('Remove this task permanently'),
                onTap: () {
                  Navigator.pop(context);
                  _showDeleteConfirmation(todo);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void _showDeleteConfirmation(Todo todo) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Task'),
        content: const Text('Are you sure you want to delete this task?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              setState(() {
                todos.remove(todo);
              });
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('${todo.title} deleted'),
                  action: SnackBarAction(
                    label: 'Undo',
                    onPressed: () {
                      setState(() {
                        todos.add(todo);
                      });
                    },
                  ),
                ),
              );
            },
            style: TextButton.styleFrom(
              foregroundColor: Colors.red,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  Widget _buildEnhancedDrawer() {
    final primaryColor = Theme.of(context).colorScheme.primary;
    
    return Drawer(
      child: Container(
        decoration: const BoxDecoration(
          color: Colors.white,
        ),
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: primaryColor,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.white.withOpacity(0.9),
                    backgroundImage: NetworkImage(
                      user?.photoUrl ?? 'https://ui-avatars.com/api/?name=${user?.name ?? 'User'}&background=random',
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    user?.name ?? 'User',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                  Text(
                    user?.email ?? 'user@example.com',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.9),
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
            
            _buildDrawerItem(
              icon: Icons.home,
              title: 'Home',
              isSelected: true,
              onTap: () => Navigator.pop(context),
            ),
            _buildDrawerItem(
              icon: Icons.analytics,
              title: 'Task Analytics',
              onTap: () {
                Navigator.pop(context);
                _navigateToScreen('/task-analysis');
              },
            ),
            _buildDrawerItem(
              icon: Icons.calendar_today,
              title: 'Calendar View',
              onTap: () {
                Navigator.pop(context);
                _navigateToScreen('/calendar');
              },
            ),
            
            const Divider(
              thickness: 1,
              indent: 16,
              endIndent: 16,
            ),
            
            _buildDrawerItem(
              icon: Icons.settings,
              title: 'Settings',
              onTap: () {
                Navigator.pop(context);
                _navigateToScreen('/settings');
              },
            ),
            _buildDrawerItem(
              icon: Icons.help_outline,
              title: 'Help & Feedback',
              onTap: () {
                Navigator.pop(context);
                _navigateToScreen('/help');
              },
            ),
            _buildDrawerItem(
              icon: Icons.logout,
              title: 'Logout',
              textColor: Colors.red,
              iconColor: Colors.red,
              onTap: () {
                Navigator.pop(context);
                _showLogoutConfirmation();
              },
            ),
            
            const SizedBox(height: 30),
            
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Text(
                'Version 1.0.0',
                style: TextStyle(
                  color: Colors.grey.shade600,
                  fontSize: 12,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _safeNavigate(Function navigationAction) {
    try {
      navigationAction();
    } catch (e) {
      print('Navigation error: ${e.toString()}');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Navigation error: ${e.toString()}')),
      );
    }
  }

  void _navigateToScreen(String routeName, {Object? arguments}) {
    try {
      if (_scaffoldKey.currentState?.isDrawerOpen ?? false) {
        Navigator.pop(context);
      }
      
      // For debugging
      print('Attempting to navigate to: $routeName');
      
      switch (routeName) {
        case '/analytics':
          _safeNavigate(() => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => AnalyticsScreen(todos: todos)),
          ));
          break;
        case '/calendar':
          _safeNavigate(() => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const CalendarScreen()),
          ));
          break;
        case '/settings':
          _safeNavigate(() => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const SettingsScreen()),
          ));
          break;
        case '/help':
          _safeNavigate(() => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const HelpScreen()),
          ));
          break;
        case '/profile':
          _safeNavigate(() {
            // Use named route navigation with error handling
            Navigator.of(context).pushNamed('/profile').catchError((error) {
              print('Error navigating to profile: $error');
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Error opening profile: $error')),
              );
              return null; // Return a value to satisfy the Future
            });
          });
          break;
        case '/notifications':
          _safeNavigate(() => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const NotificationsScreen()),
          ));
          break;
        case '/task-analysis':
          _safeNavigate(() => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const TaskAnalysisScreen()),
          ));
          break;
        case '/welcome':
          _safeNavigate(() => Navigator.pushNamedAndRemoveUntil(
            context,
            '/welcome',
            (route) => false,
          ));
          break;
        case '/add-todo':
          _safeNavigate(() => Navigator.pushNamed(
            context,
            '/add-todo',
            arguments: arguments,
          ));
          break;
        default:
          print('Warning: Attempting to navigate to unregistered route: $routeName');
          _safeNavigate(() => Navigator.pushNamed(
            context,
            routeName,
            arguments: arguments,
          ));
      }
    } catch (e) {
      print('Navigation error: ${e.toString()}');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Navigation error: ${e.toString()}')),
      );
    }
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    bool isSelected = false,
    Color? textColor,
    Color? iconColor,
  }) {
    final primaryColor = Theme.of(context).colorScheme.primary;
    
    return ListTile(
      leading: Icon(
        icon,
        color: iconColor ?? (isSelected ? primaryColor : Colors.grey.shade700),
      ),
      title: Text(
        title,
        style: TextStyle(
          color: textColor ?? (isSelected ? primaryColor : Colors.grey.shade900),
          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
        ),
      ),
      onTap: onTap,
    );
  }

  Widget _buildBottomBar() {
    return ClipRRect(
      borderRadius: const BorderRadius.only(
        topLeft: Radius.circular(20.0),
        topRight: Radius.circular(20.0),
      ),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: BottomAppBar(
          elevation: 8,
          notchMargin: 8.0,
          shape: const CircularNotchedRectangle(),
          child: Container(
            height: 60,
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Theme.of(context).colorScheme.primary.withOpacity(0.9),
                  Theme.of(context).colorScheme.primary,
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(20.0),
                topRight: Radius.circular(20.0),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: const Icon(Icons.menu, color: Colors.white),
                  tooltip: 'Menu',
                  onPressed: () {
                    try {
                      if (_scaffoldKey.currentState != null) {
                        _scaffoldKey.currentState!.openDrawer();
                      } else {
                        print('Scaffold state is null, cannot open drawer');
                      }
                    } catch (e) {
                      print('Menu error: ${e.toString()}');
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Menu error: ${e.toString()}')),
                      );
                    }
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.search, color: Colors.white),
                  tooltip: 'Search',
                  onPressed: () {
                    try {
                      _startSearch();
                    } catch (e) {
                      print('Search error: ${e.toString()}');
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Search error: ${e.toString()}')),
                      );
                    }
                  },
                ),
                const SizedBox(width: 48),
                IconButton(
                  icon: const Icon(Icons.filter_list, color: Colors.white),
                  tooltip: 'Filter',
                  onPressed: () {
                    try {
                      _showFilterDialog();
                    } catch (e) {
                      print('Filter error: ${e.toString()}');
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Filter error: ${e.toString()}')),
                      );
                    }
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.analytics_outlined, color: Colors.white),
                  tooltip: 'Analytics',
                  onPressed: () => _navigateToScreen('/analytics'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
      elevation: 0,
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primary.withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.spa,
              size: 24,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
          const SizedBox(width: 12),
          const Text(
            'TodoZen',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.search),
          tooltip: 'Search',
          onPressed: () {
            try {
              _startSearch();
            } catch (e) {
              print('Search error: ${e.toString()}');
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Search error: ${e.toString()}')),
              );
            }
          },
        ),
        IconButton(
          icon: const Icon(Icons.notifications_none),
          tooltip: 'Notifications',
          onPressed: () => _navigateToScreen('/notifications'),
        ),
        IconButton(
          icon: const Icon(Icons.person),
          tooltip: 'Profile',
          onPressed: () {
            try {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => const ProfileScreen(),
                ),
              );
            } catch (e) {
              print('Profile navigation error: ${e.toString()}');
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Could not open profile. Please try again.')),
              );
            }
          },
        ),
      ],
      bottom: TabBar(
        controller: _tabController,
        tabs: const [
          Tab(
            icon: Icon(Icons.list_alt),
            text: 'All',
          ),
          Tab(
            icon: Icon(Icons.pending_actions),
            text: 'Active',
          ),
          Tab(
            icon: Icon(Icons.task_alt),
            text: 'Completed',
          ),
        ],
        indicatorSize: TabBarIndicatorSize.label,
        indicatorWeight: 3,
        labelStyle: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 12,
        ),
      ),
    );
  }

  AppBar _buildSearchAppBar() {
    return AppBar(
      leading: IconButton(
        icon: const Icon(Icons.arrow_back),
        onPressed: _stopSearch,
      ),
      title: TextField(
        controller: _searchController,
        onChanged: _updateSearchQuery,
        autofocus: true,
        decoration: InputDecoration(
          hintText: 'Search tasks...',
          border: InputBorder.none,
          hintStyle: const TextStyle(color: Colors.black54),
          suffixIcon: _searchQuery.isNotEmpty 
            ? IconButton(
                icon: const Icon(Icons.clear),
                onPressed: () {
                  _searchController.clear();
                  _updateSearchQuery('');
                },
              ) 
            : null,
        ),
        style: const TextStyle(color: Colors.black),
      ),
      actions: const [],
    );
  }

  void _navigateToAddTodo() {
    try {
      final route = ModalRoute.of(context)?.settings.name;
      print('Current route: $route, attempting to navigate to /add-todo');
      
      Navigator.pushNamed(context, '/add-todo').then((result) {
        if (result != null && result is Todo) {
          setState(() {
            todos.add(result);
            _sortTodos();
          });
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Task added successfully')),
          );
        }
      }).catchError((error) {
        print('Error adding task: ${error.toString()}');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error adding task: ${error.toString()}')),
        );
      });
    } catch (e) {
      print('Error navigating to add task: ${e.toString()}');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: ${e.toString()}')),
      );
    }
  }

  Widget _buildTodoList({required String filterType}) {
    List<Todo> filteredTodos = [];
    switch (filterType) {
      case 'all':
        filteredTodos = _getFilteredTodos();
        break;
      case 'active':
        filteredTodos = todos.where((todo) => !todo.isCompleted).toList();
        filteredTodos = _applySearchFilter(filteredTodos);
        break;
      case 'completed':
        filteredTodos = todos.where((todo) => todo.isCompleted).toList();
        filteredTodos = _applySearchFilter(filteredTodos);
        break;
    }
    _sortList(filteredTodos);
    
    if (filteredTodos.isEmpty) {
      return _buildEmptyState(filterType);
    }
    
    return RefreshIndicator(
      onRefresh: () async {
        setState(() {
          _sortTodos();
        });
      },
      child: ListView.builder(
        controller: _scrollController,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
        itemCount: filteredTodos.length + 1,
        itemBuilder: (context, index) {
          if (index == 0) {
            return _buildListHeader(filteredTodos.length, filterType);
          }
          final todoIndex = index - 1;
          return AnimatedOpacity(
            duration: const Duration(milliseconds: 300),
            opacity: 1.0,
            curve: Curves.easeInOut,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0, 0.1),
                end: Offset.zero,
              ).animate(CurvedAnimation(
                parent: _animationController,
                curve: Interval(
                  0.4 + (todoIndex / filteredTodos.length) * 0.6,
                  1.0,
                  curve: Curves.fastOutSlowIn,
                ),
              )),
              child: Padding(
                padding: const EdgeInsets.only(bottom: 12.0),
                child: _buildEnhancedTaskCard(filteredTodos[todoIndex]),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildEmptyState(String filterType) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.network(
            filterType == 'completed'
              ? 'https://img.icons8.com/color/96/000000/task-completed.png'
              : 'https://img.icons8.com/color/96/000000/clipboard.png',
            width: 120,
            height: 120,
          ),
          const SizedBox(height: 24),
          Text(
            filterType == 'all' 
              ? 'Your task list is empty' 
              : filterType == 'active' 
                ? 'No active tasks. Good job!'
                : 'No completed tasks yet.',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.grey.shade800,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            filterType == 'all' 
              ? 'Add your first task to get started!' 
              : filterType == 'active' 
                ? 'All your tasks are completed. Time to relax!'
                : 'Complete tasks will appear here.',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey.shade600,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 32),
          if (filterType == 'all')
            ElevatedButton.icon(
              icon: const Icon(Icons.add),
              label: const Text('Create New Task'),
              onPressed: () => Navigator.pushNamed(context, '/add-todo'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildListHeader(int count, String filterType) {
    final now = DateTime.now();
    final formattedDate = '${_getDayOfWeek(now.weekday)}, ${_getMonthName(now.month)} ${now.day}';
    
    String headerText;
    switch (filterType) {
      case 'active':
        headerText = 'Active Tasks';
        break;
      case 'completed':
        headerText = 'Completed Tasks';
        break;
      default:
        headerText = 'All Tasks';
    }
    
    return Padding(
      padding: const EdgeInsets.only(bottom: 24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            formattedDate,
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey.shade600,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                headerText,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).colorScheme.primary,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  '$count ${count == 1 ? 'task' : 'tasks'}',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _getDayOfWeek(int day) {
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    return days[day - 1];
  }

  String _getMonthName(int month) {
    const months = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    return months[month - 1];
  }

  Widget _buildEnhancedTaskCard(Todo todo) {
    final dueText = _getDaysRemaining(todo.dueDate);
    final dueColor = _getDueDateColor(todo.dueDate);
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    
    Color borderColor;
    Color priorityColor;
    List<Color> gradientColors;
    switch (todo.priority) {
      case 'High':
        borderColor = Colors.red.withOpacity(0.3);
        priorityColor = Colors.red;
        gradientColors = [Colors.red.shade200, Colors.red.shade300];
        break;
      case 'Medium':
        borderColor = Colors.orange.withOpacity(0.3);
        priorityColor = Colors.orange;
        gradientColors = [Colors.orange.shade200, Colors.orange.shade300];
        break;
      default:
        borderColor = Colors.green.withOpacity(0.3);
        priorityColor = Colors.green;
        gradientColors = [Colors.green.shade200, Colors.green.shade300];
    }
    
    return Hero(
      tag: 'todo-${todo.id}',
      child: Material(
        color: Colors.transparent,
        child: Card(
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: borderColor, width: 1.5),
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () async {
              final todoCopy = Todo(
                id: todo.id,
                title: todo.title,
                description: todo.description,
                dueDate: todo.dueDate,
                isCompleted: todo.isCompleted,
                priority: todo.priority,
                categoryId: todo.categoryId,
                hasReminder: todo.hasReminder,
                reminderTime: todo.reminderTime,
                createdAt: todo.createdAt,
                updatedAt: todo.updatedAt,
              );
              
              final result = await Navigator.pushNamed(
                context,
                '/todo-detail',
                arguments: todoCopy,
              );
              
              if (result != null) {
                if (result == 'delete') {
                  setState(() {
                    todos = todos.where((t) => t.id != todo.id).toList();
                  });
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Task deleted')),
                  );
                } else if (result is Todo) {
                  setState(() {
                    todos = todos.map((t) => t.id == result.id ? result : t).toList();
                  });
                  _sortTodos();
                }
              }
            },
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 12,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: gradientColors,
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(16),
                        topRight: Radius.circular(16),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            SizedBox(
                              width: 24,
                              height: 24,
                              child: Transform.scale(
                                scale: 1.2,
                                child: Checkbox(
                                  value: todo.isCompleted,
                                  activeColor: priorityColor,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  onChanged: (bool? value) {
                                    _toggleTaskCompletion(todo, value);
                                  },
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    todo.title,
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.w600,
                                      decoration: todo.isCompleted
                                          ? TextDecoration.lineThrough
                                          : TextDecoration.none,
                                      color: todo.isCompleted
                                          ? Colors.grey
                                          : isDarkMode ? Colors.white : Colors.black87,
                                    ),
                                  ),
                                  if (todo.description.isNotEmpty) ...[
                                    const SizedBox(height: 4),
                                    Text(
                                      todo.description.length > 60
                                          ? '${todo.description.substring(0, 60)}...'
                                          : todo.description,
                                      style: TextStyle(
                                        fontSize: 14,
                                        color: Colors.grey.shade600,
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                              decoration: BoxDecoration(
                                color: priorityColor.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: priorityColor.withOpacity(0.3),
                                  width: 1,
                                ),
                              ),
                              child: Text(
                                todo.priority,
                                style: TextStyle(
                                  color: priorityColor,
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            Row(
                              children: [
                                Icon(
                                  Icons.calendar_today,
                                  size: 14,
                                  color: dueColor,
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  dueText,
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: dueColor,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(width: 16),
                            if (todo.subtasks != null && todo.subtasks!.isNotEmpty)
                              Row(
                                children: [
                                  Icon(
                                    Icons.checklist,
                                    size: 14,
                                    color: Colors.grey.shade600,
                                  ),
                                  const SizedBox(width: 6),
                                  Text(
                                    '${todo.subtasks!.where((s) => s.isCompleted).length}/${todo.subtasks!.length}',
                                    style: TextStyle(
                                      fontSize: 13,
                                      color: Colors.grey.shade600,
                                    ),
                                  ),
                                ],
                              ),
                            if (todo.tags.isNotEmpty) ...[
                              const SizedBox(width: 16),
                              Row(
                                children: [
                                  Icon(
                                    Icons.label,
                                    size: 14,
                                    color: Colors.grey.shade600,
                                  ),
                                  const SizedBox(width: 6),
                                  Text(
                                    '${todo.tags.length}',
                                    style: TextStyle(
                                      fontSize: 13,
                                      color: Colors.grey.shade600,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                            const Spacer(),
                            IconButton(
                              icon: Icon(
                                Icons.more_vert,
                                color: Colors.grey.shade600,
                              ),
                              onPressed: () => _showTaskOptionsModal(todo),
                              iconSize: 20,
                              splashRadius: 20,
                              constraints: const BoxConstraints(),
                              padding: EdgeInsets.zero,
                            ),
                          ],
                        ),
                        if (todo.tags.isNotEmpty) ...[
                          const SizedBox(height: 12),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: todo.tags.take(3).map((tag) {
                              return Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  tag,
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: Theme.of(context).colorScheme.primary,
                                  ),
                                ),
                              );
                            }).toList() + [
                              if (todo.tags.length > 3)
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: Colors.grey.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Text(
                                    '+${todo.tags.length - 3}',
                                    style: TextStyle(
                                      fontSize: 11,
                                      color: Colors.grey.shade600,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  List<Todo> _applySearchFilter(List<Todo> todos) {
    if (_searchQuery.isEmpty) return todos;
    return todos.where((todo) {
      return todo.title.toLowerCase().contains(_searchQuery.toLowerCase()) ||
             todo.description.toLowerCase().contains(_searchQuery.toLowerCase());
    }).toList();
  }

  void _sortList(List<Todo> todoList) {
    switch (_sortBy) {
      case 'Due Date':
        todoList.sort((a, b) => a.dueDate.compareTo(b.dueDate));
        break;
      case 'Priority':
        todoList.sort((a, b) {
          final priorityOrder = {
            'High': 0,
            'Medium': 1,
            'Low': 2,
          };
          return priorityOrder[a.priority]!.compareTo(priorityOrder[b.priority]!);
        });
        break;
      case 'Title':
        todoList.sort((a, b) => a.title.compareTo(b.title));
        break;
      case 'Creation Date':
        todoList.sort((a, b) => (a.id ?? 0).compareTo(b.id ?? 0));
        break;
    }
    
    if (!_sortAscending) {
      final reversedList = todoList.reversed.toList();
      todoList.clear();
      todoList.addAll(reversedList);
    }
  }

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final isDarkMode = brightness == Brightness.dark;
    
    return Scaffold(
      key: _scaffoldKey,
      appBar: _isSearching ? _buildSearchAppBar() : _buildAppBar(),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: isDarkMode 
                ? [
                    Colors.grey.shade900,
                    Colors.grey.shade800,
                  ]
                : [
                    Colors.blue.shade50.withOpacity(0.3),
                    Colors.white,
                  ],
            ),
          ),
          child: TabBarView(
            controller: _tabController,
            children: [
              _buildTodoList(filterType: 'all'),
              _buildTodoList(filterType: 'active'),
              _buildTodoList(filterType: 'completed'),
            ],
          ),
        ),
      ),
      floatingActionButton: AnimatedSlide(
        duration: const Duration(milliseconds: 300),
        offset: _showFab ? Offset.zero : const Offset(0, 2),
        child: AnimatedOpacity(
          opacity: _showFab ? 1.0 : 0.0,
          duration: const Duration(milliseconds: 300),
          child: FloatingActionButton.extended(
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            icon: const Icon(Icons.add),
            label: const Text('New Task'),
            onPressed: _navigateToAddTodo,
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: _buildBottomBar(),
      drawer: _buildEnhancedDrawer(),
    );
  }
}
