import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/todo.dart';

class TodoDetailScreen extends StatefulWidget {
  final Todo todo;

  const TodoDetailScreen({Key? key, required this.todo}) : super(key: key);

  @override
  State<TodoDetailScreen> createState() => _TodoDetailScreenState();
}

class _TodoDetailScreenState extends State<TodoDetailScreen> {
  late Todo _todo;

  @override
  void initState() {
    super.initState();
    _todo = widget.todo;
  }

  void _toggleCompleted() {
    setState(() {
      _todo = _todo.copyWith(isCompleted: !_todo.isCompleted, updatedAt: DateTime.now());
    });
  }

  Future<void> _editTodo() async {
    final result = await Navigator.pushNamed(
      context,
      '/add-todo',
      arguments: _todo,
    );

    if (result != null) {
      if (result == 'delete') {
        Navigator.pop(context, 'delete');
      } else if (result is Todo) {
        setState(() {
          _todo = result;
        });
      }
    }
  }

  void _showDeleteConfirmation() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Task'),
        content: const Text('Are you sure you want to delete this task?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.pop(context, 'delete');
            },
            style: TextButton.styleFrom(
              foregroundColor: Colors.red,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Task Details'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: _editTodo,
          ),
          IconButton(
            icon: const Icon(Icons.delete),
            color: Colors.red,
            onPressed: _showDeleteConfirmation,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildTaskHeader(),
            const SizedBox(height: 24),
            _buildDetailsCard(),
            const SizedBox(height: 16),
            if (_todo.tags.isNotEmpty) _buildTagsCard(),
            const SizedBox(height: 16),
            if (_todo.hasReminder) _buildReminderCard(),
            const SizedBox(height: 24),
            _buildActionButtons(),
          ],
        ),
      ),
    );
  }

  Widget _buildTaskHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _getColorForPriority().withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: _getColorForPriority().withOpacity(0.3),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  _todo.title,
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    decoration: _todo.isCompleted ? TextDecoration.lineThrough : null,
                  ),
                ),
              ),
              Checkbox(
                value: _todo.isCompleted,
                activeColor: _getColorForPriority(),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4),
                ),
                onChanged: (bool? value) {
                  if (value != null) {
                    _toggleCompleted();
                  }
                },
              ),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: _getColorForPriority().withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: _getColorForPriority().withOpacity(0.3),
                width: 1,
              ),
            ),
            child: Text(
              _todo.priority,
              style: TextStyle(
                color: _getColorForPriority(),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          if (_todo.description.isNotEmpty) ...[
            const SizedBox(height: 16),
            Text(
              _todo.description,
              style: Theme.of(context).textTheme.bodyLarge,
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildDetailsCard() {
    final formattedCreatedDate = DateFormat.yMMMd().add_jm().format(_todo.createdAt ?? DateTime.now());
    final formattedUpdatedDate = DateFormat.yMMMd().add_jm().format(_todo.updatedAt ?? DateTime.now());
    final formattedDueDate = DateFormat.yMMMd().format(_todo.dueDate);
    
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Details',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            _buildDetailRow(
              Icons.calendar_today,
              'Due Date',
              formattedDueDate,
              _getDueDateColor(),
            ),
            const Divider(height: 24),
            _buildDetailRow(
              Icons.access_time,
              'Created',
              formattedCreatedDate,
              null,
            ),
            const Divider(height: 24),
            _buildDetailRow(
              Icons.update,
              'Last Updated',
              formattedUpdatedDate,
              null,
            ),
            const Divider(height: 24),
            _buildDetailRow(
              _todo.isCompleted ? Icons.check_circle : Icons.pending_actions,
              'Status',
              _todo.isCompleted ? 'Completed' : 'Pending',
              _todo.isCompleted ? Colors.green : Colors.orange,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTagsCard() {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Tags',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _todo.tags.map((tag) {
                return Chip(
                  label: Text(tag),
                  backgroundColor: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildReminderCard() {
    final reminderTimeText = _formatTimeOfDay(_todo.reminderTime as TimeOfDay?);
        
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Reminder',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            _buildDetailRow(
              Icons.notifications,
              'Reminder Time',
              reminderTimeText,
              null,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String label, String value, Color? color) {
    return Row(
      children: [
        Icon(
          icon,
          color: color,
        ),
        const SizedBox(width: 16),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey.shade600,
              ),
            ),
            Text(
              value,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: color,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildActionButtons() {
    return Row(
      children: [
        Expanded(
          child: ElevatedButton.icon(
            onPressed: _toggleCompleted,
            icon: Icon(
              _todo.isCompleted ? Icons.refresh : Icons.check_circle,
              color: _todo.isCompleted ? Colors.orange : Colors.green,
            ),
            label: Text(_todo.isCompleted ? 'Mark as Incomplete' : 'Mark as Complete'),
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              backgroundColor: (_todo.isCompleted ? Colors.orange : Colors.green).withOpacity(0.1),
              foregroundColor: _todo.isCompleted ? Colors.orange : Colors.green,
            ),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: ElevatedButton.icon(
            onPressed: _editTodo,
            icon: const Icon(Icons.edit),
            label: const Text('Edit Task'),
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              backgroundColor: Theme.of(context).colorScheme.primary.withOpacity(0.1),
              foregroundColor: Theme.of(context).colorScheme.primary,
            ),
          ),
        ),
      ],
    );
  }

  Color _getColorForPriority() {
    switch (_todo.priority) {
      case 'High':
        return Colors.red;
      case 'Medium':
        return Colors.orange;
      case 'Low':
        return Colors.green;
      default:
        return Colors.blue;
    }
  }

  Color _getDueDateColor() {
    final today = DateTime.now();
    final dueDate = _todo.dueDate;
    final difference = dueDate.difference(today).inDays;
    
    if (difference < 0) {
      return Colors.red;
    } else if (difference == 0) {
      return Colors.orange;
    } else if (difference <= 3) {
      return Colors.amber;
    } else {
      return Colors.green;
    }
  }

  String _formatTimeOfDay(TimeOfDay? timeOfDay) {
    if (timeOfDay == null) return "Not set";
    final now = DateTime.now();
    final dateTime = DateTime(
      now.year, 
      now.month, 
      now.day, 
      timeOfDay.hour, 
      timeOfDay.minute
    );
    return DateFormat.jm().format(dateTime);
  }
}
