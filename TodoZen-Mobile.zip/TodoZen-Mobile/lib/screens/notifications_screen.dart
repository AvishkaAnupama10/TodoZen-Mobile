import 'package:flutter/material.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Demo notification data
    final notifications = [
      {
        'title': 'Task Due Soon',
        'message': 'Complete project proposal is due in 2 hours',
        'time': '2 hours ago',
        'type': 'reminder',
        'read': false,
      },
      {
        'title': 'Task Completed',
        'message': 'You completed "Buy groceries for weekend"',
        'time': 'Yesterday',
        'type': 'update',
        'read': true,
      },
      {
        'title': 'New Feature Available',
        'message': 'Check out the new calendar view for better planning',
        'time': '2 days ago',
        'type': 'system',
        'read': true,
      },
      {
        'title': 'Task Due Today',
        'message': 'Pay utility bills is due today',
        'time': '3 days ago',
        'type': 'reminder',
        'read': true,
      },
      {
        'title': 'Weekly Summary',
        'message': 'You completed 8 tasks this week. Great job!',
        'time': '1 week ago',
        'type': 'update',
        'read': true,
      },
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
        actions: [
          TextButton(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('All notifications marked as read')),
              );
            },
            child: const Text(
              'Mark all as read',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
      body: notifications.isEmpty
          ? _buildEmptyState(context)
          : _buildNotificationsList(context, notifications),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.notifications_none,
            size: 80,
            color: Colors.grey.shade400,
          ),
          const SizedBox(height: 16),
          Text(
            'No Notifications',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 8),
          Text(
            'You\'re all caught up!',
            style: TextStyle(
              color: Colors.grey.shade600,
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNotificationsList(BuildContext context, List<Map<String, dynamic>> notifications) {
    return ListView.builder(
      itemCount: notifications.length,
      itemBuilder: (context, index) {
        final notification = notifications[index];
        
        IconData iconData;
        Color iconColor;
        
        switch (notification['type']) {
          case 'reminder':
            iconData = Icons.alarm;
            iconColor = Colors.orange;
            break;
          case 'update':
            iconData = Icons.check_circle;
            iconColor = Colors.green;
            break;
          case 'system':
            iconData = Icons.info;
            iconColor = Colors.blue;
            break;
          default:
            iconData = Icons.notifications;
            iconColor = Colors.grey;
        }
        
        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: iconColor.withOpacity(0.2),
              child: Icon(iconData, color: iconColor),
            ),
            title: Text(
              notification['title'],
              style: TextStyle(
                fontWeight: notification['read'] ? FontWeight.normal : FontWeight.bold,
              ),
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 4),
                Text(notification['message']),
                const SizedBox(height: 4),
                Text(
                  notification['time'],
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey.shade600,
                  ),
                ),
              ],
            ),
            isThreeLine: true,
            trailing: !notification['read']
                ? Container(
                    width: 10,
                    height: 10,
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primary,
                      shape: BoxShape.circle,
                    ),
                  )
                : null,
            onTap: () {
              // View notification details
            },
          ),
        );
      },
    );
  }
}
