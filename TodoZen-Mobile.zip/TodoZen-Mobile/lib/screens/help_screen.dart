import 'package:flutter/material.dart';

class HelpScreen extends StatelessWidget {
  const HelpScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Help & Feedback'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 16),
            Text(
              'How to use TodoZen',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 16),
            _buildHelpItem(
              context,
              'Creating Tasks',
              'Tap the + button at the bottom to create a new task. Fill in details like title, description, due date, and priority.',
              Icons.add_task,
            ),
            _buildHelpItem(
              context,
              'Managing Tasks',
              'Swipe tasks to mark them as complete or delete them. Tap on a task to view details or edit it.',
              Icons.check_circle_outline,
            ),
            _buildHelpItem(
              context,
              'Filtering & Sorting',
              'Use the filter button to sort tasks by date, priority or to filter completed/pending tasks.',
              Icons.filter_list,
            ),
            _buildHelpItem(
              context,
              'Analytics',
              'View your productivity statistics and task completion rates in the Analytics section.',
              Icons.analytics_outlined,
            ),
            const SizedBox(height: 24),
            Text(
              'Send Feedback',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'We value your input!',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Let us know how we can improve TodoZen to better meet your needs.',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    const SizedBox(height: 16),
                    const TextField(
                      decoration: InputDecoration(
                        hintText: 'Enter your feedback here',
                        border: OutlineInputBorder(),
                      ),
                      maxLines: 5,
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Thank you for your feedback!'),
                            ),
                          );
                        },
                        child: const Text('Submit Feedback'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'FAQ',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 16),
            _buildFaqItem(
              context, 
              'How do I sync my tasks across devices?',
              'TodoZen automatically syncs your tasks to the cloud when you\'re logged in with your account. Just log in on any device to access your tasks.'
            ),
            _buildFaqItem(
              context, 
              'Can I set reminders for tasks?',
              'Yes! When creating or editing a task, toggle the "Add Reminder" option and select a time to be notified.'
            ),
            _buildFaqItem(
              context, 
              'How can I categorize my tasks?',
              'You can add tags to your tasks when creating or editing them. This allows you to group and filter tasks by category.'
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHelpItem(BuildContext context, String title, String description, IconData icon) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(
              icon,
              size: 28,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    description,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFaqItem(BuildContext context, String question, String answer) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: ExpansionTile(
        title: Text(
          question,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Text(answer),
          ),
        ],
      ),
    );
  }
}
