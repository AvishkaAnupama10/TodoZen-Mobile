import 'package:flutter/material.dart';
import '../models/todo.dart';

class AnalyticsScreen extends StatelessWidget {
  final List<Todo> todos;

  const AnalyticsScreen({
    Key? key,
    required this.todos,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Analytics'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.analytics_outlined,
              size: 80,
              color: Theme.of(context).colorScheme.primary.withOpacity(0.7),
            ),
            const SizedBox(height: 24),
            Text(
              'Analytics Dashboard',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Text(
                'View statistics and insights about your tasks and productivity.',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyLarge,
              ),
            ),
            const SizedBox(height: 32),
            _buildAnalyticsSummary(),
          ],
        ),
      ),
    );
  }

  Widget _buildAnalyticsSummary() {
    // Calculate some basic stats
    final completedTasks = todos.where((t) => t.isCompleted).length;
    final pendingTasks = todos.where((t) => !t.isCompleted).length;
    final highPriorityTasks = todos.where((t) => t.priority == 'High').length;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _buildStatRow('Total Tasks', todos.length.toString()),
            const Divider(),
            _buildStatRow('Completed', '$completedTasks (${(completedTasks / (todos.isEmpty ? 1 : todos.length) * 100).toStringAsFixed(0)}%)'),
            const Divider(),
            _buildStatRow('Pending', pendingTasks.toString()),
            const Divider(),
            _buildStatRow('High Priority', highPriorityTasks.toString()),
          ],
        ),
      ),
    );
  }

  Widget _buildStatRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
