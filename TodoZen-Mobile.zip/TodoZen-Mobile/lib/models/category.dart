import 'package:flutter/material.dart';

class TaskCategory {
  final String id;
  final String name;
  final Color color;
  final IconData icon;

  TaskCategory({
    required this.id,
    required this.name,
    required this.color,
    required this.icon,
  });

  // Predefined categories
  static List<TaskCategory> defaultCategories = [
    TaskCategory(
      id: '1',
      name: 'Work',
      color: Colors.blue,
      icon: Icons.work,
    ),
    TaskCategory(
      id: '2',
      name: 'Personal',
      color: Colors.purple,
      icon: Icons.person,
    ),
    TaskCategory(
      id: '3',
      name: 'Health',
      color: Colors.green,
      icon: Icons.favorite,
    ),
    TaskCategory(
      id: '4',
      name: 'Shopping',
      color: Colors.orange,
      icon: Icons.shopping_cart,
    ),
    TaskCategory(
      id: '5',
      name: 'Education',
      color: Colors.red,
      icon: Icons.school,
    ),
    TaskCategory(
      id: '6',
      name: 'Home',
      color: Colors.teal,
      icon: Icons.home,
    ),
  ];

  // Convert to Map for storage
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'color': color.value,
      'icon': icon.codePoint,
    };
  }

  // Create from Map for retrieval
  factory TaskCategory.fromMap(Map<String, dynamic> map) {
    return TaskCategory(
      id: map['id'],
      name: map['name'],
      color: Color(map['color']),
      icon: IconData(map['icon'], fontFamily: 'MaterialIcons'),
    );
  }
}
