import 'package:flutter/foundation.dart';

class Subtask {
  final int? id;
  final String title;
  bool isCompleted;
  DateTime? createdAt;

  Subtask({
    this.id,
    required this.title,
    this.isCompleted = false,
    this.createdAt,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'isCompleted': isCompleted,
      'createdAt': createdAt?.toIso8601String(),
    };
  }

  factory Subtask.fromJson(Map<String, dynamic> json) {
    return Subtask(
      id: json['id'],
      title: json['title'],
      isCompleted: json['isCompleted'] ?? false,
      createdAt: json['createdAt'] != null 
          ? DateTime.parse(json['createdAt']) 
          : null,
    );
  }

  Subtask copyWith({
    int? id,
    String? title,
    bool? isCompleted,
    DateTime? createdAt,
  }) {
    return Subtask(
      id: id ?? this.id,
      title: title ?? this.title,
      isCompleted: isCompleted ?? this.isCompleted,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}

class Todo {
  final int? id;
  final String title;
  final String description;
  final DateTime dueDate;
  bool isCompleted;
  final String priority;
  final int? categoryId;
  final bool hasReminder;
  final DateTime? reminderTime;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final List<String> tags;
  final List<Subtask>? subtasks;

  Todo({
    this.id,
    required this.title,
    this.description = '',
    required this.dueDate,
    this.isCompleted = false,
    required this.priority,
    this.categoryId,
    this.hasReminder = false,
    this.reminderTime,
    this.createdAt,
    this.updatedAt,
    this.tags = const [],
    this.subtasks,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'dueDate': dueDate.toIso8601String(),
      'isCompleted': isCompleted,
      'priority': priority,
      'categoryId': categoryId,
      'hasReminder': hasReminder,
      'reminderTime': reminderTime?.toIso8601String(),
      'createdAt': createdAt?.toIso8601String(),
      'updatedAt': updatedAt?.toIso8601String(),
      'tags': tags,
      'subtasks': subtasks?.map((s) => s.toJson()).toList(),
    };
  }

  factory Todo.fromJson(Map<String, dynamic> json) {
    return Todo(
      id: json['id'],
      title: json['title'],
      description: json['description'] ?? '',
      dueDate: DateTime.parse(json['dueDate']),
      isCompleted: json['isCompleted'] ?? false,
      priority: json['priority'] ?? 'Medium',
      categoryId: json['categoryId'],
      hasReminder: json['hasReminder'] ?? false,
      reminderTime: json['reminderTime'] != null 
          ? DateTime.parse(json['reminderTime']) 
          : null,
      createdAt: json['createdAt'] != null 
          ? DateTime.parse(json['createdAt']) 
          : null,
      updatedAt: json['updatedAt'] != null 
          ? DateTime.parse(json['updatedAt']) 
          : null,
      tags: json['tags'] != null 
          ? List<String>.from(json['tags']) 
          : [],
      subtasks: json['subtasks'] != null 
          ? (json['subtasks'] as List)
              .map((s) => Subtask.fromJson(s))
              .toList() 
          : null,
    );
  }

  Todo copyWith({
    int? id,
    String? title,
    String? description,
    DateTime? dueDate,
    bool? isCompleted,
    String? priority,
    int? categoryId,
    bool? hasReminder,
    DateTime? reminderTime,
    DateTime? createdAt,
    DateTime? updatedAt,
    List<String>? tags,
    List<Subtask>? subtasks,
  }) {
    return Todo(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      dueDate: dueDate ?? this.dueDate,
      isCompleted: isCompleted ?? this.isCompleted,
      priority: priority ?? this.priority,
      categoryId: categoryId ?? this.categoryId,
      hasReminder: hasReminder ?? this.hasReminder,
      reminderTime: reminderTime ?? this.reminderTime,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      tags: tags ?? List.from(this.tags),
      subtasks: subtasks ?? this.subtasks?.map((s) => s.copyWith()).toList(),
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    
    return other is Todo &&
      other.id == id &&
      other.title == title &&
      other.description == description &&
      other.dueDate == dueDate &&
      other.isCompleted == isCompleted &&
      other.priority == priority &&
      other.categoryId == categoryId &&
      other.hasReminder == hasReminder &&
      other.reminderTime == reminderTime &&
      listEquals(other.tags, tags) &&
      listEquals(other.subtasks, subtasks);
  }

  @override
  int get hashCode {
    return id.hashCode ^
      title.hashCode ^
      description.hashCode ^
      dueDate.hashCode ^
      isCompleted.hashCode ^
      priority.hashCode ^
      categoryId.hashCode ^
      hasReminder.hashCode ^
      reminderTime.hashCode ^
      tags.hashCode ^
      subtasks.hashCode;
  }
}

class Category {
  final int id;
  final String name;
  final String color;
  final String icon;

  Category({
    required this.id,
    required this.name,
    required this.color,
    required this.icon,
  });
}
