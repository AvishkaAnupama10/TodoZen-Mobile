class User {
  final String id;
  final String name;
  final String email;
  String photoUrl;
  String bio;
  DateTime joinDate;

  User({
    required this.id,
    required this.name,
    required this.email,
    this.photoUrl = '',
    this.bio = '',
    DateTime? joinDate,
  }) : joinDate = joinDate ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'photoUrl': photoUrl,
      'bio': bio,
      'joinDate': joinDate.toIso8601String(),
    };
  }

  factory User.fromMap(Map<String, dynamic> map) {
    return User(
      id: map['id'],
      name: map['name'],
      email: map['email'],
      photoUrl: map['photoUrl'] ?? '',
      bio: map['bio'] ?? '',
      joinDate: DateTime.parse(map['joinDate']),
    );
  }

  User copyWith({
    String? name,
    String? email,
    String? photoUrl,
    String? bio,
  }) {
    return User(
      id: id,
      name: name ?? this.name,
      email: email ?? this.email,
      photoUrl: photoUrl ?? this.photoUrl,
      bio: bio ?? this.bio,
      joinDate: joinDate,
    );
  }
}
